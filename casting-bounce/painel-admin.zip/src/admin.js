// Painel de visualização das inscrições (lê a planilha e as pastas do Drive pela API /api/admin).
const root = document.getElementById('admin');
const nav = document.getElementById('admin-nav');
const drawer = document.getElementById('drawer');
const panel = drawer.querySelector('.drawer-panel');
const esc = (s = '') => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const list = (s = '') => String(s).split(',').map((x) => x.trim()).filter(Boolean);

const store = {
  get: () => { try { return sessionStorage.getItem('casting_admin') || ''; } catch { return ''; } },
  set: (t) => { try { t ? sessionStorage.setItem('casting_admin', t) : sessionStorage.removeItem('casting_admin'); } catch {} },
};
let token = store.get();
let state = { fields: [], items: [], planilha: null, pastaRaiz: null, casting: {} };
const filesCache = new Map();

async function api(path) {
  const r = await fetch(path, { headers: { Authorization: `Bearer ${token}` } });
  if (r.status === 401) { logout(); throw new Error('login'); }
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.message || 'Erro');
  return data;
}
const thumb = (id, s = 600) => `/api/admin/miniatura?id=${encodeURIComponent(id)}&s=${s}&t=${encodeURIComponent(token)}`;
const openLink = (f) => (f.abrir?.startsWith('/__arquivo_local/') ? `${f.abrir}?t=${encodeURIComponent(token)}` : f.abrir);

/* ---------------- LOGIN ---------------- */
function loginView(msg = '') {
  nav.innerHTML = '';
  root.className = 'login-wrap';
  root.innerHTML = `
    <form class="login" id="login">
      <p class="kicker">PAINEL DO CASTING</p>
      <h1>ENTRAR</h1>
      <label for="senha">Senha</label>
      <input type="password" id="senha" autocomplete="current-password" autofocus>
      <button class="btn" type="submit">ENTRAR →</button>
      <p class="form-msg">${esc(msg)}</p>
    </form>`;
  root.querySelector('#login').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = e.target.querySelector('button');
    btn.disabled = true;
    const r = await fetch('/api/admin/login', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ senha: root.querySelector('#senha').value }) });
    const data = await r.json().catch(() => ({}));
    btn.disabled = false;
    if (!r.ok) return (root.querySelector('.form-msg').textContent = data.message || 'Erro ao entrar.');
    token = data.token; store.set(token); load();
  });
}
function logout() { token = ''; store.set(''); closeDrawer(); loginView(); }

/* ---------------- LISTA ---------------- */
async function load() {
  root.className = 'section admin-main';
  root.innerHTML = '<p class="muted">Carregando inscrições…</p>';
  try { const d = await api('/api/admin/inscricoes'); state = { ...d, items: d.inscricoes || [] }; } catch (e) { if (e.message !== 'login') root.innerHTML = `<p class="form-msg">${esc(e.message)}</p>`; return; }

  nav.innerHTML = `
    ${state.planilha ? `<a href="${state.planilha}" target="_blank" rel="noopener">PLANILHA ↗</a>` : ''}
    ${state.pastaRaiz ? `<a href="${state.pastaRaiz}" target="_blank" rel="noopener">DRIVE ↗</a>` : ''}
    <a href="#" id="sair">SAIR</a>`;
  nav.querySelector('#sair').onclick = (e) => { e.preventDefault(); logout(); };

  const estilos = [...new Set(state.items.flatMap((i) => [...list(i.estilos_dominio), ...list(i.estilos_estudados)]))].sort();
  const opts = (key) => [...new Set(state.items.map((i) => i[key]).filter(Boolean))].sort();
  const sel = (key, label, values) => `<select data-f="${key}"><option value="">${label}</option>${values.map((v) => `<option>${esc(v)}</option>`).join('')}</select>`;

  root.innerHTML = `
    <div class="admin-head">
      <div>
        <p class="kicker">PAINEL · ${esc(state.casting.titulo || '')}</p>
        <h2><span id="count">${state.items.length}</span> <span id="count-label">PERFIS</span></h2>
      </div>
    </div>
    <div class="toolbar">
      <input type="text" id="q" placeholder="Buscar nome, cidade, Instagram…">
      ${sel('genero', 'Gênero', opts('genero'))}
      <select data-f="_estilo"><option value="">Estilo (domina)</option>${estilos.map((v) => `<option>${esc(v)}</option>`).join('')}</select>
      ${sel('disponivel_show', 'Show 12/12', opts('disponivel_show'))}
      ${sel('disponivel_ensaios', 'Ensaios', opts('disponivel_ensaios'))}
      ${sel('tem_experiencia', 'Experiência', opts('tem_experiencia'))}
    </div>
    <div class="cards-grid" id="grid"></div>`;
  root.querySelector('#q').addEventListener('input', render);
  root.querySelectorAll('[data-f]').forEach((s) => s.addEventListener('change', render));
  render();
}

function filtered() {
  const q = root.querySelector('#q').value.trim().toLowerCase();
  const f = Object.fromEntries([...root.querySelectorAll('[data-f]')].map((s) => [s.dataset.f, s.value]));
  return state.items.filter((i) => {
    if (q && !Object.values(i).join(' ').toLowerCase().includes(q)) return false;
    if (f._estilo && !list(i.estilos_dominio).includes(f._estilo)) return false;
    return Object.entries(f).every(([k, v]) => k === '_estilo' || !v || i[k] === v);
  });
}

function render() {
  const items = filtered();
  root.querySelector('#count').textContent = items.length;
  root.querySelector('#count-label').textContent = items.length === 1 ? 'PERFIL' : 'PERFIS';
  const grid = root.querySelector('#grid');
  if (!state.items.length) { grid.innerHTML = '<p class="muted">Nenhuma inscrição ainda.</p>'; return; }
  if (!items.length) { grid.innerHTML = '<p class="muted">Nenhum perfil com esses filtros.</p>'; return; }
  grid.innerHTML = items.map((i) => {
    const incompleto = /INCOMPLETO|ENVIANDO/.test(i._status);
    const show = i.disponivel_show === 'Sim';
    return `
    <button class="pcard" data-linha="${i._linha}">
      <div class="pcard-img" data-pasta="${esc(i._pastaId)}"><span class="ph">${esc((i.nome_artistico || '?')[0])}</span></div>
      <div class="pcard-body">
        <strong>${esc(i.nome_artistico || i.nome_completo)}</strong>
        <span class="muted">${[i.genero, i.idade && `${i.idade} anos`, i.cidade].filter(Boolean).map(esc).join(' · ')}</span>
        <span class="tags">${list(i.estilos_dominio).slice(0, 4).map((e) => `<em>${esc(e)}</em>`).join('')}</span>
        <span class="badges">
          <b class="${show ? 'ok' : 'no'}">SHOW ${show ? '✓' : '✕'}</b>
          ${i.tem_experiencia === 'Sim' ? '<b>EXPERIÊNCIA</b>' : ''}
          ${incompleto ? '<b class="warn">ARQUIVOS INCOMPLETOS</b>' : ''}
        </span>
      </div>
    </button>`;
  }).join('');
  grid.querySelectorAll('.pcard').forEach((c) => c.addEventListener('click', () => openProfile(Number(c.dataset.linha))));
  grid.querySelectorAll('.pcard-img').forEach((el) => io.observe(el));
}

/* miniaturas dos cards: carrega só o que aparece na tela, 4 por vez */
const queue = []; let running = 0;
const io = new IntersectionObserver((entries) => entries.forEach((e) => {
  if (!e.isIntersecting) return;
  io.unobserve(e.target); queue.push(e.target); pump();
}), { rootMargin: '300px' });
function pump() {
  while (running < 4 && queue.length) {
    const el = queue.shift(); running++;
    loadCover(el).finally(() => { running--; pump(); });
  }
}
async function files(pasta) {
  if (!pasta) return [];
  if (!filesCache.has(pasta)) filesCache.set(pasta, api(`/api/admin/arquivos?pasta=${encodeURIComponent(pasta)}`).then((d) => d.arquivos).catch(() => []));
  return filesCache.get(pasta);
}
async function loadCover(el) {
  const foto = (await files(el.dataset.pasta)).find((f) => f.tipo === 'foto');
  if (!foto) return;
  const img = new Image();
  img.alt = '';
  img.onload = () => { el.innerHTML = ''; el.appendChild(img); };
  img.src = thumb(foto.id, 500);
}

/* ---------------- PERFIL ---------------- */
async function openProfile(linha) {
  const i = state.items.find((x) => x._linha === linha);
  if (!i) return;
  const insta = (i.instagram || '').replace(/^@/, '').replace(/.*instagram\.com\//, '').replace(/[/?].*$/, '');
  const zap = (i.whatsapp || '').replace(/\D/g, '');
  const skip = new Set(['_status', '_pasta', 'nome_artistico']);
  const ficha = state.fields.filter((f) => !skip.has(f.key) && f.type !== 'files' && i[f.key])
    .map((f) => `<dt>${esc(f.label)}</dt><dd>${esc(i[f.key])}</dd>`).join('');

  panel.innerHTML = `
    <button class="close" data-close aria-label="Fechar">×</button>
    <p class="kicker">${esc(i._recebido)} · ${esc(i._status)}</p>
    <h2>${esc(i.nome_artistico || i.nome_completo)}</h2>
    <p class="muted">${esc(i.nome_completo)}</p>
    <p class="links">
      ${zap ? `<a href="https://wa.me/55${zap}" target="_blank" rel="noopener">WHATSAPP ↗</a>` : ''}
      ${insta ? `<a href="https://instagram.com/${esc(insta)}" target="_blank" rel="noopener">INSTAGRAM ↗</a>` : ''}
      ${i.email ? `<a href="mailto:${esc(i.email)}">E-MAIL ↗</a>` : ''}
      ${i._pasta?.startsWith('http') ? `<a href="${esc(i._pasta)}" target="_blank" rel="noopener">PASTA NO DRIVE ↗</a>` : ''}
    </p>
    <h3>FOTOS</h3><div class="gallery" id="g-fotos"><p class="muted">Carregando…</p></div>
    <h3>VÍDEOS</h3><div class="gallery videos" id="g-videos"></div>
    <h3>FICHA</h3><dl>${ficha}</dl>`;
  drawer.hidden = false;
  document.body.style.overflow = 'hidden';

  const arqs = await files(i._pastaId);
  const fotos = arqs.filter((f) => f.tipo === 'foto');
  const videos = arqs.filter((f) => f.tipo === 'video');
  panel.querySelector('#g-fotos').innerHTML = fotos.length
    ? fotos.map((f) => `<a href="${esc(openLink(f))}" target="_blank" rel="noopener"><img src="${thumb(f.id, 1000)}" alt="" loading="lazy"></a>`).join('')
    : '<p class="muted">Nenhuma foto.</p>';
  panel.querySelector('#g-videos').innerHTML = videos.length
    ? videos.map((f, n) => `<a class="vid" href="${esc(openLink(f))}" target="_blank" rel="noopener">
        <img src="${thumb(f.id, 600)}" alt="" onerror="this.remove()"><span>▶ VÍDEO ${n + 1}</span></a>`).join('')
    : '<p class="muted">Nenhum vídeo.</p>';
}
function closeDrawer() { drawer.hidden = true; document.body.style.overflow = ''; }
drawer.addEventListener('click', (e) => { if (e.target.closest('[data-close]')) closeDrawer(); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeDrawer(); });

token ? load() : loginView();
